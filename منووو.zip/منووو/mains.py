import pygame, sys
from button import Button

pygame.init()
SCREEN = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Menu")
BG = pygame.image.load("assets/Background.png")

# فونت برای متن‌ها
def get_font(size):
    return pygame.font.Font("assets/font.ttf", size)

# تابع صفحه بازی (نمایش سه عکس)
def play():
    images = [
        pygame.image.load("assets/image1.png").convert(),  # عکس اول
        pygame.image.load("assets/image2.png").convert(),  # عکس دوم
        pygame.image.load("assets/image3.png").convert()   # عکس سوم
    ]
    image_rects = [
        images[0].get_rect(center=(200, 200)),
        images[1].get_rect(center=(200, 200)),
        images[2].get_rect(center=(100, 100))
    ]

    while True:
        SCREEN.fill("black")
        PLAY_MOUSE_POS = pygame.mouse.get_pos()

        # نمایش متن "BACK"
        PLAY_BACK = Button(image=None, pos=(640, 600), 
                           text_input="BACK", font=get_font(75), base_color="White", hovering_color="Green")
        PLAY_BACK.changeColor(PLAY_MOUSE_POS)
        PLAY_BACK.update(SCREEN)

        # نمایش سه عکس
        for i, image in enumerate(images):
            SCREEN.blit(image, image_rects[i])

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BACK.checkForInput(PLAY_MOUSE_POS):
                    main_menu()
                # بررسی کلیک روی عکس‌ها
                for i, rect in enumerate(image_rects):
                    if rect.collidepoint(event.pos):
                        message = ["سلام", "چطوری", "اتمام"][i]
                        show_message(message)

        pygame.display.update()

# تابع نمایش پیغام
def show_message(message):
    while True:
        MESSAGE_MOUSE_POS = pygame.mouse.get_pos()
        SCREEN.fill("white")
        MESSAGE_TEXT = get_font(75).render(message, True, "Black")
        MESSAGE_RECT = MESSAGE_TEXT.get_rect(center=(640, 360))
        SCREEN.blit(MESSAGE_TEXT, MESSAGE_RECT)

        MESSAGE_BACK = Button(image=None, pos=(640, 500), 
                              text_input="BACK", font=get_font(75), base_color="Black", hovering_color="Green")
        MESSAGE_BACK.changeColor(MESSAGE_MOUSE_POS)
        MESSAGE_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if MESSAGE_BACK.checkForInput(MESSAGE_MOUSE_POS):
                    return  # بازگشت به صفحه قبل

        pygame.display.update()

# تابع صفحه تنظیمات
def options():
    while True:
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()
        SCREEN.fill("white")
        OPTIONS_TEXT = get_font(45).render("kian.", True, "Black")
        OPTIONS_RECT = OPTIONS_TEXT.get_rect(center=(640, 260))
        SCREEN.blit(OPTIONS_TEXT, OPTIONS_RECT)

        OPTIONS_BACK = Button(image=None, pos=(640, 460), 
                              text_input="BACK", font=get_font(75), base_color="Black", hovering_color="Green")
        OPTIONS_BACK.changeColor(OPTIONS_MOUSE_POS)
        OPTIONS_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if OPTIONS_BACK.checkForInput(OPTIONS_MOUSE_POS):
                    main_menu()

        pygame.display.update()

# تابع منوی اصلی
def main_menu():
    while True:
        SCREEN.blit(BG, (0, 0))
        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(100).render("MAIN MENU", True, "#b68f40")
        MENU_RECT = MENU_TEXT.get_rect(center=(640, 100))

        PLAY_BUTTON = Button(image=pygame.image.load("assets/Play Rect.png"), pos=(640, 250), 
                             text_input="PLAY", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        OPTIONS_BUTTON = Button(image=pygame.image.load("assets/Options Rect.png"), pos=(640, 400), 
                                text_input="OPTIONS", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        QUIT_BUTTON = Button(image=pygame.image.load("assets/Quit Rect.png"), pos=(640, 550), 
                             text_input="QUIT", font=get_font(75), base_color="#d7fcd4", hovering_color="White")

        SCREEN.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON, OPTIONS_BUTTON, QUIT_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()
                if OPTIONS_BUTTON.checkForInput(MENU_MOUSE_POS):
                    options()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()

main_menu()