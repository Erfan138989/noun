import pygame, sys
from button import Button

pygame.init()
SCREEN = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Menu")
BG = pygame.image.load("assets/Background.png")

def get_font(size):
    return pygame.font.Font("assets/font.ttf", size)

def show_message(message):
    while True:
        MESSAGE_MOUSE_POS = pygame.mouse.get_pos()
        SCREEN.fill("black")
        MESSAGE_TEXT = get_font(45).render(message, True, "White")
        MESSAGE_RECT = MESSAGE_TEXT.get_rect(center=(640, 260))
        SCREEN.blit(MESSAGE_TEXT, MESSAGE_RECT)
        MESSAGE_BACK = Button(image=None, pos=(640, 460), 
                               text_input="BACK", font=get_font(75), base_color="White", hovering_color="Green")
        MESSAGE_BACK.changeColor(MESSAGE_MOUSE_POS)
        MESSAGE_BACK.update(SCREEN)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if MESSAGE_BACK.checkForInput(MESSAGE_MOUSE_POS):
                    play()
        pygame.display.update()

def play():
    while True:
        PLAY_MOUSE_POS = pygame.mouse.get_pos()
        SCREEN.fill("black")
        
        # بارگذاری عکس‌ها
        image1 = pygame.image.load("assets/image1.png")
        image2 = pygame.image.load("assets/image2.png")
        image3 = pygame.image.load("assets/image3.png")
        
        # تغییر اندازه عکس‌ها
        image1 = pygame.transform.scale(image1, (200, 200))
        image2 = pygame.transform.scale(image2, (200, 200))
        image3 = pygame.transform.scale(image3, (200, 200))
        
        # نمایش عکس‌ها
        SCREEN.blit(image1, (200, 260))
        SCREEN.blit(image2, (500, 260))
        SCREEN.blit(image3, (800, 260))
        
        # ایجاد دکمه‌های برگشت
        PLAY_BACK = Button(image=None, pos=(640, 550), 
                           text_input="BACK", font=get_font(75), base_color="White", hovering_color="Green")
        PLAY_BACK.changeColor(PLAY_MOUSE_POS)
        PLAY_BACK.update(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                # بررسی کلیک روی عکس‌ها
                if 200 <= PLAY_MOUSE_POS[0] <= 400 and 260 <= PLAY_MOUSE_POS[1] <= 460:
                    show_message("سلام")
                if 500 <= PLAY_MOUSE_POS[0] <= 700 and 260 <= PLAY_MOUSE_POS[1] <= 460:
                    show_message("چطوری")
                if 800 <= PLAY_MOUSE_POS[0] <= 1000 and 260 <= PLAY_MOUSE_POS[1] <= 460:
                    show_message("اتمام")
                if PLAY_BACK.checkForInput(PLAY_MOUSE_POS):
                    main_menu()
        pygame.display.update()

def options():
    while True:
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()
        SCREEN.fill("white")
        OPTIONS_TEXT = get_font(45).render("kian.", True, "Black")
        OPTIONS_RECT = OPTIONS_TEXT.get_rect(center=(640, 260))
        SCREEN.blit(OPTIONS_TEXT, OPTIONS_RECT)
        OPTIONS_BACK = Button(image=None, pos=(640, 460), 
                              text_input="BACK", font=get_font(75), base_color="Black", hovering_color="Green")
        OPTIONS_BACK.changeColor(OPTIONS_MOUSE_POS)
        OPTIONS_BACK.update(SCREEN)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if OPTIONS_BACK.checkForInput(OPTIONS_MOUSE_POS):
                    main_menu()
        pygame.display.update()

def main_menu():
    while True:
        SCREEN.blit(BG, (0, 0))
        MENU_MOUSE_POS = pygame.mouse.get_pos()
        MENU_TEXT = get_font(100).render("MAIN MENU", True, "#b68f40")
        MENU_RECT = MENU_TEXT.get_rect(center=(640, 100))
        PLAY_BUTTON = Button(image=pygame.image.load("assets/Play Rect.png"), pos=(640, 250), 
                             text_input="PLAY", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        OPTIONS_BUTTON = Button(image=pygame.image.load("assets/Options Rect.png"), pos=(640, 400), 
                                text_input="OPTIONS", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        QUIT_BUTTON = Button(image=pygame.image.load("assets/Quit Rect.png"), pos=(640, 550), 
                              text_input="QUIT", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        SCREEN.blit(MENU_TEXT, MENU_RECT)
        for button in [PLAY_BUTTON, OPTIONS_BUTTON, QUIT_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()
                if OPTIONS_BUTTON.checkForInput(MENU_MOUSE_POS):
                    options()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()
        pygame.display.update()

main_menu()