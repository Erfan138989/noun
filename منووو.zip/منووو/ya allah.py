import pygame
import sys
from bidi.algorithm import get_display
import arabic_reshaper

# تعریف قسمت‌های مختلف اسکلت و محدوده‌های آنها بر اساس تصویر اصلی (730x1222)
original_skeleton_parts = {
    "جمجمه": (290, 50, 440, 160),
    "ستون فقرات": (345, 160, 385, 500),
    "قفسه سینه": (250, 160, 480, 350),
    "استخوان لگن": (260, 460, 470, 550),
    "بازوی چپ": (100, 250, 250, 500),
    "بازوی راست": (480, 250, 630, 500),
    "پای چپ": (300, 550, 360, 1100),  # تغییر در y2
    "پای راست": (390, 550, 450, 1100),  # تغییر در y2
}

# اطلاعات درباره‌ی قسمت‌های اسکلت
skeleton_info = {
    "جمجمه": "جمجمه شامل ۲۲ استخوان است که از مغز محافظتش می‌کنند.",
    "ستون فقرات": "ستون فقرات شامل ۳۳ مهره است که به حرکت و پشتیبانی بدن کمک می‌کند.",
    "قفسه سینه": "این قسمت شامل دنده‌ها و استخوان جناغ است که از اندام‌های داخلی محافظت می‌کنند.",
    "استخوان لگن": "لگن بخشی از اسکلت است که وزن بدن را تحمل کرده و به حرکت کمک می‌کند.",
    "بازوی چپ": "بازو شامل استخوان‌های بازو، ساعد، و مچ دست است.",
    "بازوی راست": "بازو شامل استخوان‌های بازو، ساعد، و مچ دست است.",
    "پای چپ": "پای چپ شامل استخوان ران، درشت‌نی، نازک‌نی و استخوان‌های کف پا است.",
    "پای راست": "پای راست شامل استخوان ران، درشت‌نی، نازک‌نی و استخوان‌های کف پا است.",
}

# تابع مقیاس‌بندی مختصات
def scale_coordinates(parts, original_width, original_height, new_width, new_height):
    scale_width = new_width / original_width
    scale_height = new_height / original_height
    scaled_parts = {}
    for part, (x1, y1, x2, y2) in parts.items():
        scaled_x1 = int(x1 * scale_width)
        scaled_y1 = int(y1 * scale_height)
        scaled_x2 = int(x2 * scale_width)
        scaled_y2 = int(y2 * scale_height)
        scaled_parts[part] = (scaled_x1, scaled_y1, scaled_x2, scaled_y2)
    return scaled_parts

# مقیاس‌بندی قسمت‌های اسکلت به اندازه 1080x720
skeleton_parts = scale_coordinates(original_skeleton_parts, 730, 1222, 1080, 720)

# کلاس دکمه
class Button:
    def __init__(self, image, pos, text_input, font, base_color, hovering_color):
        self.image = image
        self.x_pos = pos[0]
        self.y_pos = pos[1]
        self.font = font
        self.base_color, self.hovering_color = base_color, hovering_color
        self.text_input = text_input
        self.text = self.font.render(self.text_input, True, self.base_color)
        if self.image is None:
            self.image = self.text
        self.rect = self.image.get_rect(center=(self.x_pos, self.y_pos))
        self.text_rect = self.text.get_rect(center=(self.x_pos, self.y_pos))

    def update(self, screen):
        if self.image is not None:
            screen.blit(self.image, self.rect)
        screen.blit(self.text, self.text_rect)

    def checkForInput(self, position):
        if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
            return True
        return False

    def changeColor(self, position):
        if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
            self.text = self.font.render(self.text_input, True, self.hovering_color)
        else:
            self.text = self.font.render(self.text_input, True, self.base_color)

class SkeletonApp:
    def __init__(self, image_path):
        pygame.init()
        self.screen = pygame.display.set_mode((1080, 720))  # تنظیم اندازه پنجره به 1080x720
        pygame.display.set_caption("اسکلت انسان - نمایش تعاملی")
        
        # بارگذاری تصویر اسکلت و مقیاس‌بندی آن به 1080x720
        self.image = pygame.image.load("Skeleton.jpg").convert_alpha()
        self.image = pygame.transform.scale(self.image, (1080, 720))
        
        # بارگذاری فونت فارسی
        self.font = pygame.font.Font("Vazir.ttf", 24)
        self.tooltip_font = pygame.font.Font("Vazir.ttf", 18)
        self.tooltip_text = ""
        self.tooltip_pos = (0, 0)

        # بارگذاری تصویر پس‌زمینه منو
        self.bg = pygame.image.load("assets/Background.png").convert()

    def run(self):
        self.main_menu()

    def main_menu(self):
        while True:
            self.screen.blit(self.bg, (0, 0))
            menu_mouse_pos = pygame.mouse.get_pos()
            
            menu_text = self.get_font(100).render("MAIN MENU", True, "#b68f40")
            menu_rect = menu_text.get_rect(center=(540, 100))
            
            play_button = Button(image=pygame.image.load("assets/Play Rect.png"), pos=(540, 250), 
                                 text_input="PLAY", font=self.get_font(75), base_color="#d7fcd4", hovering_color="White")
            quit_button = Button(image=pygame.image.load("assets/Quit Rect.png"), pos=(540, 550), 
                                 text_input="QUIT", font=self.get_font(75), base_color="#d7fcd4", hovering_color="White")
            
            self.screen.blit(menu_text, menu_rect)
            
            for button in [play_button, quit_button]:
                button.changeColor(menu_mouse_pos)
                button.update(self.screen)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if play_button.checkForInput(menu_mouse_pos):
                        self.play()
                    if quit_button.checkForInput(menu_mouse_pos):
                        pygame.quit()
                        sys.exit()
            
            pygame.display.update()

    def play(self):
        while True:
            play_mouse_pos = pygame.mouse.get_pos()
            self.screen.fill("white")  # تغییر رنگ پس‌زمینه به سفید
            
            # بارگذاری تصویر اسکلت
            self.screen.blit(self.image, (0, 0))
            
            # نمایش tooltip
            if self.tooltip_text:
                reshaped_text = arabic_reshaper.reshape(self.tooltip_text)
                bidi_text = get_display(reshaped_text)
                tooltip_surface = self.tooltip_font.render(bidi_text, True, (0, 0, 0))
                self.screen.blit(tooltip_surface, self.tooltip_pos)
            
            # ایجاد دکمه برگشت
            play_back = Button(image=None, pos=(540, 650), 
                               text_input="BACK", font=self.get_font(75), base_color="Black", hovering_color="Green")
            play_back.changeColor(play_mouse_pos)
            play_back.update(self.screen)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEMOTION:
                    self.on_mouse_move(event.pos)
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.on_mouse_click(event.pos)
                    if play_back.checkForInput(play_mouse_pos):
                        self.main_menu()
            
            pygame.display.update()

    def on_mouse_move(self, pos):
        """ بررسی می‌کند که آیا ماوس روی یکی از قسمت‌ها قرار دارد یا نه. """
        x, y = pos
        for part, (x1, y1, x2, y2) in skeleton_parts.items():
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.tooltip_text = part
                self.tooltip_pos = (x + 10, y + 10)
                return
        self.tooltip_text = ""

    def on_mouse_click(self, pos):
        """ بررسی کلیک ماوس روی یکی از قسمت‌های اسکلت. """
        x, y = pos
        for part, (x1, y1, x2, y2) in skeleton_parts.items():
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.show_skeleton_info(part)
                return

    def show_skeleton_info(self, part):
        """ نمایش اطلاعات مربوط به بخش انتخاب‌شده. """
        info_text = skeleton_info.get(part, "اطلاعات موجود نیست.")
        reshaped_text = arabic_reshaper.reshape(info_text)
        bidi_text = get_display(reshaped_text)
        info_surface = self.font.render(bidi_text, True, (0, 0, 0))
        info_rect = info_surface.get_rect(center=(self.screen.get_width() // 2, self.screen.get_height() // 2))
        self.screen.blit(info_surface, info_rect)
        pygame.display.flip()
        pygame.time.wait(2000)

    def get_font(self, size, font_name="Vazir.ttf"):
        return pygame.font.Font(f"assets/{font_name}", size)

if __name__ == "__main__":
    app = SkeletonApp("Skeleton.jpg")  # مسیر تصویر اسکلت
    app.run()